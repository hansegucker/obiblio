<?php
$PDF_font['type'] = 'Core';
$PDF_font['bbox'] = array(-23, -250, 715, 805);
for($i=0;$i<=255;$i++)
	$PDF_font['cw'][chr($i)]=600;
?>
