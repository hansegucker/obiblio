<?php
echo serialize($_SERVER['argv']);
?>
