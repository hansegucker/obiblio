<h1>Inhalte:</h1>
<ol>
  <li>OPAC und Suchergebnisse</li>
    <ol type="a">
      <li><a href="../shared/help.php?page=opac">Onlinekatalog (OPAC)</a></li>
      <li><a href="../shared/help.php?page=biblioSearch">Suchergebnisse</a></li>
    </ol>
  <li>Generelle Konzepte der Bibliotheksverwaltung</li>
    <ol type="a">
      <li><a href="../shared/help.php?page=status">Status-�nderungen der Medien verstehen</a></li>
      <li><a href="../shared/help.php?page=barcodes">Barcodes verstehen</a></li>
    </ol>
  <li>Hilfe zur Ausleihe</li>
    <ol type="a">
      <li><a href="../shared/help.php?page=circulation">Mitgliedersuche (Startseite der Ausleihe)</a></li>
      <li><a href="../shared/help.php?page=memberView">Mitgliederinfo</a></li>
      <li><a href="../shared/help.php?page=opacLookup">Barcodesuche</a></li>
      <li><a href="../shared/help.php?page=checkin">Medienr�ckgabe</a></li>
    </ol>
  <li>Hilfe zur Katalogisierung</li>
    <ol type="a">
      <li><a href="../shared/help.php?page=biblioEdit">Neue Medien und Medien editieren</a></li>
      <li><a href="../shared/help.php?page=biblioCopyEdit">Neues Exemplar und Exemplar editieren</a></li>
    </ol>
  
</ol>
