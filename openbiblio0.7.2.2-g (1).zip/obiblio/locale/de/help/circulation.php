<h1>Benutzersuche (Ausleihe-Start):</h1>
<br><br>

Hilfe Untersektionen:
<ul>
  <li><a href="#barc">Ausleihe mit oder ohne aufgeklebte Barcodes</a></li>
</ul>
<br>

<a name="barc">
Ausleihe mit oder ohne aufgeklebte Barcodes</a>:
<br>
Die Openbiblio Ausleihformulare sind designed um eine effiziente Ausleihe zu gew�hrleisten, wenn man einen Barcode-Scanner sowie  
<a href="../shared/help.php?page=barcodes">Barcodes</a> 
die auf die Mitgliederkarten und auf die Exemplare gedruckt sind verwendet.
<br>
Es ist aber genauso m�glich die Funktionen zu nutzen, wenn man keine Barcodes benutzt; Benutzer k�nnen nach dem Nachnamen und die OPAC-basierte 
<a href="../shared/help.php?page=opacLookup">Barcode-Suche</a> 
findet die Barcodenummer des Exemplars heraus, f�r Ausleihe, R�ckgabe oder Vorbestellung.
