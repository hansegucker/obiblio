insert into %prfx%material_type_dm values (null,'Audiokassetten','N',10,5,'tape.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'Buch','Y',20,10,'book.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'AudioCD','N',10,5,'cd.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'CD-Rom','N',5,3,'cd.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'Ausstattung','N',3,0,'case.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'Zeitschrift','N',10,5,'mag.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'Karte','N',5,3,'map.gif', 4, 2);
insert into %prfx%material_type_dm values (null,'Video/DVD','N',5,3,'camera.gif', 4, 2);

