insert into %prfx%settings
values (
  'Meine Bibliothek'
  ,'../images/sampleLogo.png'
  ,'N'
  ,'M-F 8-21, Sa 12-17, So 13-17'
  ,'111-222-3333'
  ,null
  ,'../opac/index.php'
  ,20
  ,10
  ,'0.7.1'
  ,1
  ,6
  ,'Y'
  ,14
  ,'de'
  ,'iso-8859-1'
  ,null
)
;
