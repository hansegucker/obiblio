insert into %prfx%member values (1,101,sysdate(),sysdate(),1,'Cat','Huckle','101 1st Street\nBusyTown,IA 12345','111-222-3333',null,'me@mydomain.name',2,'0000-00-00');
insert into %prfx%member values (2,102,sysdate(),sysdate(),1,'Baggins','Bilbo','Hole 1, 1st Street\nThe Shire, IA 12345','111-222-3333',null,'me@mydomain.name',1,'0000-00-00');
insert into %prfx%member values (3,103,sysdate(),sysdate(),1,'Baggins','Frodo','Hole 2, 1st Street\nThe Shire, IA 12345','111-222-3333',null,'me@mydomain.name',1,'0000-00-00');
