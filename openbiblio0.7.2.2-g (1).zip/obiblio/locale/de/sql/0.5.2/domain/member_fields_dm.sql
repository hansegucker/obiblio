insert into %prfx%member_fields_dm values ('schoolGrade','Schulklasse','N');
insert into %prfx%member_fields_dm values ('schoolTeacher','Lehrer','N');
