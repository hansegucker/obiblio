insert into %prfx%mbr_classify_dm values ('1','Erwachsene','Y',0.00);
insert into %prfx%mbr_classify_dm values ('2','Jugendliche','N',0.00);
