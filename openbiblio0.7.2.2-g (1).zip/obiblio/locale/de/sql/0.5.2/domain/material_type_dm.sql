insert into %prfx%material_type_dm values (1,'Audiokassetten','N','tape.gif');
insert into %prfx%material_type_dm values (2,'Buch','Y','book.gif');
insert into %prfx%material_type_dm values (3,'AudioCD','N','cd.gif');
insert into %prfx%material_type_dm values (4,'CD-Rom','N','cd.gif');
insert into %prfx%material_type_dm values (5,'Ausstattung','N','case.gif');
insert into %prfx%material_type_dm values (6,'Zeitschrift','N','mag.gif');
insert into %prfx%material_type_dm values (7,'Karte','N','map.gif');
insert into %prfx%material_type_dm values (8,'Video/DVD','N','camera.gif');
