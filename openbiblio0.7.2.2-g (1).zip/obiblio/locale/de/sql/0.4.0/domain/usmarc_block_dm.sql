insert into %prfx%usmarc_block_dm values (0,'Kontrollinformationen, Zahlen und Codes');
insert into %prfx%usmarc_block_dm values (1,'Haupteintrag');
insert into %prfx%usmarc_block_dm values (2,'Titel, Untertitel, Verlag, Reihe, Edition, Erscheinungsjahr');
insert into %prfx%usmarc_block_dm values (3,'Physikalische Beschreibung, Seitenzahlen, Gr��e');
insert into %prfx%usmarc_block_dm values (4,'Informationen �ber die Serie');
insert into %prfx%usmarc_block_dm values (5,'Inhaltsangabe, Zusammenfassung, Themenbereich und Anmerkungen');
insert into %prfx%usmarc_block_dm values (6,'Schlagw�rter');
insert into %prfx%usmarc_block_dm values (7,'Zus�tzliche Eintr�ge, nicht Serie-n und Themenbezogen');
insert into %prfx%usmarc_block_dm values (8,'Seriennebeneintragungen');
insert into %prfx%usmarc_block_dm values (9,'Lokale Daten');

