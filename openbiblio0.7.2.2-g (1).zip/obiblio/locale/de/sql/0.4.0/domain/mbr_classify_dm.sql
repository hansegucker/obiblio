insert into %prfx%mbr_classify_dm values ('a','Erwachsene','N');
insert into %prfx%mbr_classify_dm values ('j','Jugendliche','Y');
