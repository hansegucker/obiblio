insert into %prfx%material_type_dm values (null,'Audiokassetten','N',10,5,'tape.gif');
insert into %prfx%material_type_dm values (null,'Buch','Y',20,10,'book.gif');
insert into %prfx%material_type_dm values (null,'AudioCD','N',10,5,'cd.gif');
insert into %prfx%material_type_dm values (null,'CD-Rom','N',5,3,'cd.gif');
insert into %prfx%material_type_dm values (null,'Ausstattung','N',3,0,'case.gif');
insert into %prfx%material_type_dm values (null,'Zeitschrift','N',10,5,'mag.gif');
insert into %prfx%material_type_dm values (null,'Karte','N',5,3,'map.gif');
insert into %prfx%material_type_dm values (null,'Video/DVD','N',5,3,'camera.gif');
