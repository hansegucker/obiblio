insert into %prfx%transaction_type_dm values ('-p','Zahlung','Y');
insert into %prfx%transaction_type_dm values ('-r','Gutschrift','N');
insert into %prfx%transaction_type_dm values ('+c','Geb�hr','N');
