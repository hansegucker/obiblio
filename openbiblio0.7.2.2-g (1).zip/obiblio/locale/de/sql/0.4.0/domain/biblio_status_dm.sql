insert into %prfx%biblio_status_dm values ('in','verf�gbar','Y');
insert into %prfx%biblio_status_dm values ('out','ausgeliehen','N');
insert into %prfx%biblio_status_dm values ('mnd','besch�digt','N');
insert into %prfx%biblio_status_dm values ('dis','in Pr�sentation','N');
insert into %prfx%biblio_status_dm values ('hld','vorbestellt','N');
insert into %prfx%biblio_status_dm values ('lst','verloren','N');
insert into %prfx%biblio_status_dm values ('ln','Leihgabe','N');
insert into %prfx%biblio_status_dm values ('ord','bestellt','N');
insert into %prfx%biblio_status_dm values ('crt','in Eingangsablage','N');
