insert into %prfx%settings
values (
  'Meine Bibliothek'
  ,'../images/sampleLogo.png'
  ,'N'
  ,'M-F 8-21, Sa 12-17, So 13-17'
  ,'111-222-3333'
  ,null
  ,'../opac/index.php'
  ,20
  ,10
  ,'0.4.0'
  ,1
  ,6
  ,'Y'
  ,'de'
  ,'iso-8859-1'
  ,null
)
;
