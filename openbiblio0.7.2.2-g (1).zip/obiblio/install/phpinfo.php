<?php
 phpinfo();
?>
