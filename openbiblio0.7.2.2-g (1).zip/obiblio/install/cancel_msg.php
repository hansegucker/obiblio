<?php
/* This file is part of a copyrighted work; it is distributed with NO WARRANTY.
 * See the file COPYRIGHT.html for more details.
 */
 
  include("../install/header.php");

?>
<br>
<h1>OpenBiblio Installation:</h1>

OpenBiblio install process has been cancelled.<br><br>
<a href="../install_instructions.html">View Install Instructions</a>

<?php include("../install/footer.php"); ?>
